/**
 * 
 */
/**
 * 
 */
module BloodBankManagement {
	requires java.desktop;
	requires java.sql;
}
